# egyptian heiroglyphics > 2023-05-20 12:17pm
https://universe.roboflow.com/cv-project-j10ka/egyptian-heiroglyphics

Provided by a Roboflow user
License: CC BY 4.0

